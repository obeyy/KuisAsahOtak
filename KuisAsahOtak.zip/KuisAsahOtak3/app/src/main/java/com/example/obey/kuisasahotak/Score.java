package com.example.obey.kuisasahotak;

/**
 * Created by Fachba on 1/15/2018.
 */

public class Score {
    public int hscore;

    public Score(int hscore) {
        this.hscore = hscore;
    }

    public int getHscore() {
        return hscore;
    }

    public void setHscore(int hscore) {
        this.hscore = hscore;
    }
}
