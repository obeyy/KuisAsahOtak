package com.example.obey.kuisasahotak;

import android.app.Application;

import com.firebase.client.Firebase;

/**
 * Created by mYPC on 20/01/2018.
 */

public class Quiz extends Application {
    @Override
    public void onCreate() {
        super.onCreate();

        Firebase.setAndroidContext(this);
    }
}
