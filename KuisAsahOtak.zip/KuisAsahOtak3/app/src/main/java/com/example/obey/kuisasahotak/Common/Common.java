package com.example.obey.kuisasahotak.Common;

import com.example.obey.kuisasahotak.Model.Soal;

import java.util.ArrayList;
import java.util.List;

/**
 * Created by mYPC on 20/01/2018.
 */

public class Common {
    public static List<Soal> soalList = new ArrayList<>();
}
