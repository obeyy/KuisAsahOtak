package com.example.obey.kuisasahotak;

/**
 * Created by Fachba on 1/14/2018.
 */

public class Question {

    public Question() {
    }

    public String questions[] = {
            "1.Ibukota Indonesia?",
            "2.Ibukota Jawa Tengah?",
            "3.Ibukota Jawa Timur?",
            "4.Ibukota Bali?",
            "5.Ibukota Jawa Barat?",
            "6.Ibukota Sumatera utara?",
            "7.Ibukota NTB?"
    };

    private String choices[][] = {
            {"Jakarta", "Surabaya", "Bandung", "Semarang"},
            {"Surabaya", "Semarang", "Jakarta", "Bandung"},
            {"Jakarta", "Surabaya", "Bandung", "Semarang"},
            {"Surabaya", "Semarang", "Denpasar", "Bandung"},
            {"Jakarta", "Surabaya", "Bandung", "Semarang"},
            {"Surabaya", "Medan", "Jakarta", "Bandung"},
            {"Medan", "Denpasar", "Surabaya", "Mataram"}
    };

    private String correctAnswer[]={"Jakarta", "Semarang", "Surabaya","Denpasar","Bandung","Medan","Mataram"};

    public String getQuestion(int a){
        String question = questions[a];
        return question;
    }

    public String getChoice1(int a){
        String choice = choices[a][0];
        return choice;
    }

    public String getChoice2(int a){
        String choice = choices[a][1];
        return choice;
    }

    public String getChoice3(int a){
        String choice = choices[a][2];
        return choice;
    }

    public String getChoice4(int a){
        String choice = choices[a][3];
        return choice;
    }

    public String getCorrectAnswer(int a){
        String answer = correctAnswer[a];
        return answer;
    }
}
