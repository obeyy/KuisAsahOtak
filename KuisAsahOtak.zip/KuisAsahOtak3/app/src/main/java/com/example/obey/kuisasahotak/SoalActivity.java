package com.example.obey.kuisasahotak;

import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.support.annotation.Nullable;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.firebase.client.DataSnapshot;
import com.firebase.client.Firebase;
import com.firebase.client.FirebaseError;
import com.firebase.client.ValueEventListener;

import java.util.Random;

public class SoalActivity extends AppCompatActivity {

    private TextView tvSkorView, tvSoal, tvKes;
    private Button btnPilihan1, btnPilihan2, btnPilihan3, btnPilihan4,skip,back;
    private static final String TAG = SoalActivity.class.getSimpleName();
    private SharedPreferences mPref;
    private static final String PREF_NAME = TAG+"_prefs";

    private int Skor = 0;
    private String jawaban;
    private int mQuestionsLenght =30;
    private int kesempatan=3;
    Random r = new Random();
    private Firebase SoalRef, Pilihan1Ref, Pilihan2Ref, Pilihan3Ref, Pilihan4Ref, JawabanRef;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_soal);
        mPref = getSharedPreferences(PREF_NAME,MODE_PRIVATE);

        tvSkorView = findViewById(R.id.score);
        tvSoal = findViewById(R.id.question);
        tvKes = findViewById(R.id.stage);
        tvKes.setText("Kesempatan : "+kesempatan+" X");
        back=findViewById(R.id.button7);
        back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
            }
        });

        btnPilihan1 = findViewById(R.id.answer1);
        btnPilihan2 = findViewById(R.id.answer2);
        btnPilihan3 = findViewById(R.id.answer3);
        btnPilihan4 = findViewById(R.id.answer4);
        skip=findViewById(R.id.button11);
        skip.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (Skor>=15)
                {
                    skip();
                }
                else
                {
                    AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SoalActivity.this);
                    alertDialogBuilder.setMessage("Point Anda Kurang dari 15")
                            .setCancelable(false)
                            .setPositiveButton("OK",
                                    new DialogInterface.OnClickListener(){
                                        @Override
                                        public void onClick(DialogInterface dialogInterface, int i){

                                        }
                                    });
                    AlertDialog alertDialog = alertDialogBuilder.create();
                    alertDialog.show();
                }

            }
        });

        updateSoal(r.nextInt(mQuestionsLenght));

        btnPilihan1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnPilihan1.getText().equals(jawaban)){
                    Skor = Skor + 5;
                    updateSkor(Skor);
                    highscore(Skor);
                    jawabanBenar();
                    updateSoal(r.nextInt(mQuestionsLenght));

                }else {
                    updateSkor(Skor);
                    kesempatan--;
                    jawabanSalah(kesempatan);
                    if(kesempatan==0)
                    {
                        gameOver(Skor);
                    }
                    tvKes.setText("Kesempatan : "+kesempatan+" X");
                }
            }
        });

        btnPilihan2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnPilihan2.getText().equals(jawaban)){
                    Skor = Skor + 5;
                    updateSkor(Skor);
                    highscore(Skor);
                    jawabanBenar();
                    updateSoal(r.nextInt(mQuestionsLenght));

                }else {
                    updateSkor(Skor);
                    kesempatan--;
                    jawabanSalah(kesempatan);
                    if(kesempatan==0)
                    {
                        gameOver(Skor);
                    }
                    tvKes.setText("Kesempatan : "+kesempatan+" X");
                }
            }
        });

        btnPilihan3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnPilihan3.getText().equals(jawaban)){
                    Skor = Skor + 5;
                    updateSkor(Skor);
                    highscore(Skor);
                    jawabanBenar();
                    updateSoal(r.nextInt(mQuestionsLenght));

                }else {
                    updateSkor(Skor);
                    kesempatan--;
                    jawabanSalah(kesempatan);
                    if(kesempatan==0)
                    {
                        gameOver(Skor);
                    }
                    tvKes.setText("Kesempatan : "+kesempatan+" X");
                }
            }
        });

        btnPilihan4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(btnPilihan4.getText().equals(jawaban)){
                    Skor = Skor + 5;
                    updateSkor(Skor);
                    highscore(Skor);
                    jawabanBenar();
                    updateSoal(r.nextInt(mQuestionsLenght));

                }else {
                    updateSkor(Skor);
                    kesempatan--;
                    jawabanSalah(kesempatan);
                    if(kesempatan==0)
                    {
                        gameOver(Skor);
                    }
                    tvKes.setText("Kesempatan : "+kesempatan+" X");
                }
            }
        });
    }

    private void skip() {
        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SoalActivity.this);
        alertDialogBuilder.setMessage("Apakah Anda Yakin Menggunakannya \n Point Anda akan Berkurang 15.")
                .setCancelable(false)
                .setPositiveButton("YA",
                        new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i){
                                Skor = Skor - 15;
                                updateSkor(Skor);
                                highscore(Skor);
                                updateSoal(r.nextInt(mQuestionsLenght));
                            }
                        })
                .setNegativeButton("TIDAK",
                        new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i){

                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void updateSoal(int nomorSoal){
        SoalRef = new Firebase("https://db-ngasahotak.firebaseio.com/Soal/"+ nomorSoal +"/soal");
        SoalRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String soal = dataSnapshot.getValue(String.class);
                tvSoal.setText("\n\n"+soal);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });

        Pilihan1Ref = new Firebase("https://db-ngasahotak.firebaseio.com/Soal/"+ nomorSoal +"/pilihanA");
        Pilihan1Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String pilihan = dataSnapshot.getValue(String.class);
                btnPilihan1.equals(pilihan);
                btnPilihan1.setText(pilihan);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });

        Pilihan2Ref = new Firebase("https://db-ngasahotak.firebaseio.com/Soal/"+ nomorSoal +"/pilihanB");
        Pilihan2Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String pilihan = dataSnapshot.getValue(String.class);
                btnPilihan2.setText(pilihan);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });

        Pilihan3Ref = new Firebase("https://db-ngasahotak.firebaseio.com/Soal/"+ nomorSoal +"/pilihanC");
        Pilihan3Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String pilihan = dataSnapshot.getValue(String.class);
                btnPilihan3.setText((pilihan));
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });

        Pilihan4Ref = new Firebase("https://db-ngasahotak.firebaseio.com/Soal/"+ nomorSoal +"/pilihanD");
        Pilihan4Ref.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                String pilihan = dataSnapshot.getValue(String.class);
                btnPilihan4.setText(pilihan);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });

        JawabanRef = new Firebase("https://db-ngasahotak.firebaseio.com/Soal/"+ nomorSoal +"/jawaban");
        JawabanRef.addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(DataSnapshot dataSnapshot) {
                jawaban = dataSnapshot.getValue(String.class);
            }

            @Override
            public void onCancelled(FirebaseError firebaseError) {

            }
        });

    }

    private void updateSkor(int skor){
        tvSkorView.setText("Coins : "+ Skor);
    }


    private void jawabanBenar() {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SoalActivity.this);
        alertDialogBuilder.setMessage("Jawaban Anda Benar, Coin anda + 5 ")
                .setCancelable(false)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i){

                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void jawabanSalah(int kesempatan) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SoalActivity.this);
        alertDialogBuilder.setMessage("Jawaban Anda Salah, Coba Lagi \n Kesempatan Anda Tinggal "+kesempatan+" X")
                .setCancelable(false)
                .setPositiveButton("OK",
                        new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i){

                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }

    private void highscore(int mScore) {
        int pertama =Integer.parseInt(mPref.getString("PERTAMA","0"));
        int kedua = Integer.parseInt(mPref.getString("KEDUA","0"));
        int ketiga = Integer.parseInt(mPref.getString("KETIGA","0"));
        if (mScore>=pertama)
        {
            SharedPreferences.Editor editor = mPref.edit();
            editor.putString("PERTAMA", String.valueOf(mScore));
            editor.apply();
        }
        else if(mScore>=kedua&&mScore<pertama)
        {
            SharedPreferences.Editor editor = mPref.edit();
            editor.putString("KEDUA", String.valueOf(mScore));
            editor.apply();
        }
        else if (mScore>=ketiga)
        {
            SharedPreferences.Editor editor = mPref.edit();
            editor.putString("KETIGA", String.valueOf(mScore));
            editor.apply();
        }
    }

    private void gameOver(int mScore) {

        AlertDialog.Builder alertDialogBuilder = new AlertDialog.Builder(SoalActivity.this);
        alertDialogBuilder.setMessage("Game Over! Your Score is "+ mScore+" points.")
                .setCancelable(false)
                .setPositiveButton("NEW GAME",
                        new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i){
                                startActivity(new Intent(getApplicationContext(), SoalActivity.class));
                                finish();
                            }
                        })
                .setNegativeButton("EXIT",
                        new DialogInterface.OnClickListener(){
                            @Override
                            public void onClick(DialogInterface dialogInterface, int i){
                                finish();
                            }
                        });
        AlertDialog alertDialog = alertDialogBuilder.create();
        alertDialog.show();
    }
}
