package com.example.obey.kuisasahotak;

import android.content.SharedPreferences;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class HighActivity extends AppCompatActivity {
    private static final String TAG = SoalActivity.class.getSimpleName();
    private SharedPreferences mPref;
    private static final String PREF_NAME = TAG+"_prefs";

    TextView tvpertma,tvkedua,tvketiga;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_high);

        mPref = getSharedPreferences(PREF_NAME,MODE_PRIVATE);

        tvpertma=findViewById(R.id.textView3);
        String pertama = mPref.getString("PERTAMA","0");
        tvpertma.setText("1. SCORE : "+pertama);

        tvkedua=findViewById(R.id.textView4);
        String kedua = mPref.getString("KEDUA","0");
        tvkedua.setText("2. SCORE : "+kedua);

        tvketiga=findViewById(R.id.textView5);
        String ketiga = mPref.getString("KETIGA","0");
        tvketiga.setText("3. SCORE : "+ketiga);
    }
}
